extern void echo_test();
extern void via_test();
extern void restart();
extern void start_ram();
extern void write_to_RAM();
extern void init_vec();
