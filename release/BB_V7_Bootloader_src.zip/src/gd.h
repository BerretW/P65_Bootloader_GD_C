extern void __fastcall__ GD_puts(const char * s);
extern void __fastcall__ GD_print_nl(const char * s);
