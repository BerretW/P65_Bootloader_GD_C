extern void kbinit();
extern char kbinput();
extern char kbscan();
