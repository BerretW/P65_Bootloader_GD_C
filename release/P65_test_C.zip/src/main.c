#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#include "kernel_lib.h"


void setup(){
  ACIA_INIT();
  GD_INIT();
  KBINIT();
}


void main(void) {
  char c;
  setup();

  PRNTLN("APPARTUS PROJEKT65 test program");
  PRNTLN("w for start write to RAM");
  PRNTLN("m for start monitor");
  c = CHRIN();

  while(1){
    if (c == 'm') PRNTLN("m for start monitor");
    if (c == 'w') {
      PRNTLN("Cekam na data pro zapis do RAM");

    }
  }
}
